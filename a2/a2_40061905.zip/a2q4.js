var names = ["oop"];
var currentName;
var i = 0;

do{
	currentName = prompt("Enter words", "")
	if(currentName != ""){
		names[i] = currentName
	}
}while(currentName != "");





